#!/usr/bin/env bash
set -euo pipefail

release_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
target_dir="$(cd "${1:-$PWD}" && pwd -P)"

if [[ "$target_dir" == "/" || "$target_dir" == "/root" || "$target_dir" == "/workspace" ]]; then
  echo "Destino rechazado por seguridad: $target_dir"
  exit 2
fi
if [[ "$release_dir" == "$target_dir" || "$release_dir" == "$target_dir/"* ]]; then
  echo "Extrae el ZIP fuera del proyecto, por ejemplo dentro de /tmp."
  exit 2
fi
if [[ ! -f "$target_dir/package.json" || ! -d "$target_dir/client" || ! -d "$target_dir/server" ]]; then
  echo "El destino no parece ser la raíz del Repl actual: $target_dir"
  echo "Abre Shell desde la raíz del proyecto y vuelve a ejecutar el comando."
  exit 2
fi
if [[ ! -f "$release_dir/MANIFEST_SHA256.txt" ]]; then
  echo "Falta MANIFEST_SHA256.txt; el paquete está incompleto."
  exit 2
fi

echo "Verificando integridad del paquete..."
(cd "$release_dir" && sha256sum --quiet -c MANIFEST_SHA256.txt)

managed=(
  client server shared script migrations tests scripts docs
  package.json package-lock.json tsconfig.json vite.config.ts drizzle.config.ts
  postcss.config.js tailwind.config.ts components.json
  .env.example README.md SECURITY_AUDIT.md
  INSTRUCCIONES_REPLIT.md AUDITORIA_RELEASE.md RELEASE_SOURCE.json
)

backup_dir="$target_dir/.tloque_backups"
npm_cache_dir="$target_dir/.tloque_cache/npm"
mkdir -p "$backup_dir"
mkdir -p "$npm_cache_dir"
timestamp="$(date -u +%Y%m%dT%H%M%SZ)"
backup_file="$backup_dir/codigo_antes_de_${timestamp}.tar.gz"
existing=()
for path in "${managed[@]}"; do
  [[ -e "$target_dir/$path" ]] && existing+=("$path")
done
if [[ ${#existing[@]} -eq 0 ]]; then
  echo "No se encontraron archivos que respaldar; instalación cancelada."
  exit 2
fi
(cd "$target_dir" && tar -czf "$backup_file" -- "${existing[@]}")
echo "Respaldo de código creado: $backup_file"

restore_previous() {
  trap - ERR
  echo "La instalación falló. Restaurando el código anterior..." >&2
  for path in "${managed[@]}"; do
    rm -rf -- "$target_dir/$path"
  done
  rm -rf -- "$target_dir/dist"
  tar -xzf "$backup_file" -C "$target_dir"
  (
    cd "$target_dir"
    rm -rf -- node_modules
    if [[ -f package-lock.json ]]; then
      NPM_CONFIG_CACHE="$npm_cache_dir" npm ci --no-audit --no-fund >/dev/null 2>&1 || true
    else
      NPM_CONFIG_CACHE="$npm_cache_dir" npm install --package-lock=false --no-audit --no-fund >/dev/null 2>&1 || true
    fi
    if [[ -f script/build.ts ]]; then
      npm run build >/dev/null 2>&1 || true
    fi
  )
  echo "Código anterior restaurado desde: $backup_file" >&2
}
trap restore_previous ERR

for path in "${managed[@]}"; do
  rm -rf -- "$target_dir/$path"
done
rm -rf -- "$target_dir/dist"

for path in "${managed[@]}"; do
  if [[ -e "$release_dir/$path" ]]; then
    cp -a -- "$release_dir/$path" "$target_dir/$path"
  fi
done

cd "$target_dir"
echo "Instalando dependencias verificadas..."
rm -rf -- node_modules
NPM_CONFIG_CACHE="$npm_cache_dir" npm ci --no-audit --no-fund
echo "Comprobando TypeScript..."
npm run check
echo "Ejecutando pruebas..."
npm test
echo "Construyendo producción..."
npm run build

trap - ERR
echo
echo "Código instalado y verificado correctamente."
echo "Todavía no se modificó la base de datos."
echo "Siguiente paso: bash scripts/migrar.sh REVISAR"
echo "Para restaurar: bash scripts/restaurar_codigo.sh '$backup_file' RESTAURAR"
