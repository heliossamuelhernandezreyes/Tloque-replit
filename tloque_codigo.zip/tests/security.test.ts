import test from "node:test"
import assert from "node:assert/strict"
import { isSafeHttpsUrl, isSafeStorageKey } from "../shared/media"
import { checkInvariants, poolCushion, TICKET } from "../shared/gacha"
import { rateLimit } from "../server/rateLimit"

test("las claves de audiolibro nunca escapan del almacenamiento", () => {
  for (const valid of ["books/12/chapter-0.mp3", "cache/a.b-c_1/audio.m4a"]) {
    assert.equal(isSafeStorageKey(valid), true, valid)
  }
  for (const invalid of ["", "/etc/passwd", "../secret", "books/../secret", "books\\secret.mp3", "books//x.mp3", "./x.mp3", "books/"]) {
    assert.equal(isSafeStorageKey(invalid), false, invalid)
  }
})

test("las salidas HTTPS no aceptan credenciales ni esquemas alternos", () => {
  assert.equal(isSafeHttpsUrl("https://storage.example/audio.mp3"), true)
  assert.equal(isSafeHttpsUrl("http://storage.example/audio.mp3"), false)
  assert.equal(isSafeHttpsUrl("https://user:secret@storage.example/audio.mp3"), false)
  assert.equal(isSafeHttpsUrl("file:///etc/passwd"), false)
})

test("el límite global no se evade cambiando la ruta", () => {
  const middleware = rateLimit(60_000, 2, "api-global")
  let allowed = 0
  let denied = 0
  const request = (path: string) => ({
    ip: "203.0.113.7",
    method: "POST",
    path,
    isAuthenticated: () => false,
  }) as any
  const response = {
    setHeader: () => undefined,
    status(code: number) {
      assert.equal(code, 429)
      denied++
      return this
    },
    json: () => undefined,
  } as any
  middleware(request("/one"), response, () => { allowed++ })
  middleware(request("/two"), response, () => { allowed++ })
  middleware(request("/three"), response, () => { allowed++ })
  assert.equal(allowed, 2)
  assert.equal(denied, 1)
})

test("el sorteo cuesta veinte pesos y conserva solvencia matemática", () => {
  assert.deepEqual(TICKET, { price: 10, direct: 3, pool: 4, house: 3 })
  assert.deepEqual(checkInvariants(), { ok: true })
  assert.ok(poolCushion() > 0)
})
