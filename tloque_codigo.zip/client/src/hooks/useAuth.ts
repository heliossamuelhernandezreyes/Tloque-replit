import { useQuery, useQueryClient } from "@tanstack/react-query"

export interface AuthUser {
  id:          number
  email:       string
  name:        string
  avatar:      string
  banner:      string
  bio:         string
  frame:       string
  socialLinks: Record<string, string>
  isAdmin:     boolean  // viene del servidor — basado en tabla admins
  persona:     "reader" | "author" | "admin"
  roles:       { reader: true; author: boolean; admin: boolean }
  capabilities: {
    createBooks: boolean
    manageOwnBooks: boolean
    manageEditions: boolean
    manageCatalog: boolean
    manageAudioCatalog: boolean
    manageFrames: boolean
    manageAdmins: boolean
    runDiagnostics: boolean
  }
  subscription: {
    plan: string
    status: string
    expiresAt: string | null
  }
}

const AUTH_KEY = ["/api/auth/me"]

export function useAuth() {
  const queryClient = useQueryClient()

  const { data: user, isLoading } = useQuery<AuthUser | null>({
    queryKey: AUTH_KEY,
    queryFn: async () => {
      const res = await fetch("/api/auth/me", { credentials: "include" })
      if (!res.ok) return null
      return res.json()
    },
    // Sin staleTime alto — isAdmin puede cambiar entre sesiones
    staleTime:          0,
    gcTime:             5 * 60 * 1000,
    retry:              false,
    refetchOnWindowFocus: true,
  })

  return {
    user:            user ?? null,
    isLoading,
    isLoggedIn:      !!user,
    isAdmin:         !!user?.isAdmin,
    refreshAuth:     () => queryClient.invalidateQueries({ queryKey: AUTH_KEY }),
    loginWithGoogle: () => { window.location.href = "/api/auth/google" },
    logout:          async () => {
      await fetch("/api/auth/logout", { method: "POST", credentials: "include" })
      queryClient.setQueryData(AUTH_KEY, null)
      window.location.href = "/"
    },
  }
}
