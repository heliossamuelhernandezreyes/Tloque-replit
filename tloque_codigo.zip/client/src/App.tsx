import { lazy, Suspense, useState, useEffect, type ReactNode, type ComponentType } from "react"
import { Switch, Route } from "wouter"
import { queryClient } from "./lib/queryClient"
import { QueryClientProvider } from "@tanstack/react-query"
import { Toaster } from "@/components/ui/toaster"
import { TooltipProvider } from "@/components/ui/tooltip"
import { GenreProvider } from "@/context/GenreContext"
import { SettingsProvider } from "@/context/SettingsContext"
import { useSettings } from "@/context/SettingsContext"
import { MotionConfig } from "framer-motion"
import SplashScreen from "@/components/SplashScreen"
import Onboarding  from "@/components/Onboarding"
import LoginScreen from "@/components/LoginScreen"
import { useAuth } from "@/hooks/useAuth"
import { pullAndMerge } from "@/lib/sync"

const NotFound = lazy(() => import("@/pages/not-found"))
const Home = lazy(() => import("@/pages/home"))
const Library = lazy(() => import("@/pages/library"))
const Reader = lazy(() => import("@/pages/reader"))
const BookPage = lazy(() => import("@/pages/book"))
const Editor = lazy(() => import("@/pages/editor"))
const AuthorPage = lazy(() => import("@/pages/author"))
const ClaimPage = lazy(() => import("@/pages/claim"))
const FrameWorkshop = lazy(() => import("@/pages/FrameWorkshop"))
const FrameGallery = lazy(() => import("@/pages/FrameGallery"))
const CardStudio = lazy(() => import("@/pages/CardStudio"))
const GachaScreen = lazy(() => import("@/pages/GachaScreen"))
const FlickerLab = lazy(() => import("@/pages/FlickerLab"))
const AudioCatalogAdmin = lazy(() => import("@/pages/AudioCatalogAdmin"))
const ProfileHub = lazy(() => import("@/pages/ProfileHub"))
const Inbox = lazy(() => import("@/pages/Inbox"))
const Editions = lazy(() => import("@/pages/Editions"))
const AdminHub = lazy(() => import("@/pages/AdminHub"))
import { CardViewerProvider } from "@/components/CardViewer"
import { MusicProvider } from "@/audio/MusicProvider"

const SESSION_KEY = "novareads_splash_shown"

function Router() {
  const adminPage = (Page: ComponentType<any>) => () => <AdminOnly><Page /></AdminOnly>
  return (
    <Suspense fallback={<RouteFallback />}>
      <Switch>
        <Route path="/"                        component={Home}     />
        <Route path="/library"                 component={Library}  />
        <Route path="/book/:id"                component={BookPage} />
        <Route path="/read/:bookId/:chapterId" component={Reader}   />
        <Route path="/editor"                  component={Editor}     />
        <Route path="/profile"                 component={ProfileHub} />
        <Route path="/inbox"                   component={Inbox} />
        <Route path="/editions"                component={Editions} />
        <Route path="/author/:name"            component={AuthorPage} />
        <Route path="/claim/:folio"            component={ClaimPage} />
        <Route path="/sorteo"                  component={GachaScreen} />
        <Route path="/tarjetas"                component={CardStudio} />
        <Route path="/tarjetas/:bookId"        component={CardStudio} />
        <Route path="/marcos"                  component={FrameGallery} />
        <Route path="/admin"                   component={adminPage(AdminHub)} />
        <Route path="/admin/diag"              component={adminPage(FlickerLab)} />
        <Route path="/admin/marcos"            component={adminPage(FrameWorkshop)} />
        <Route path="/admin/fonoteca"          component={adminPage(AudioCatalogAdmin)} />
        <Route component={NotFound} />
      </Switch>
    </Suspense>
  )
}

function AdminOnly({ children }: { children: ReactNode }) {
  const { isAdmin, isLoading } = useAuth()
  if (isLoading) return <RouteFallback />
  if (!isAdmin) return <NotFound />
  return <>{children}</>
}

function RouteFallback() {
  return (
    <div className="fixed inset-0 bg-black flex items-center justify-center" role="status" aria-live="polite">
      <div className="w-2 h-2 rounded-full animate-pulse bg-white/30" />
    </div>
  )
}

function MotionPreferences({ children }: { children: ReactNode }) {
  const { settings } = useSettings()
  return (
    <MotionConfig reducedMotion={settings.reduceMotion ? "always" : "user"}>
      {children}
    </MotionConfig>
  )
}

function AppContent() {
  const { isLoading, isLoggedIn } = useAuth()

  // Al abrir la app logueado: juntar racha y progreso con la nube (una vez)
  useEffect(() => {
    if (isLoggedIn) pullAndMerge()
  }, [isLoggedIn])

  const [showSplash,     setShowSplash]     = useState(
    () => !sessionStorage.getItem(SESSION_KEY)
  )
  const [showOnboarding, setShowOnboarding] = useState(
    () => !localStorage.getItem("novareads_onboarding_done")
  )

  // Mientras verifica si hay sesión activa — pantalla negra mínima
  if (isLoading) return (
    <div className="fixed inset-0 bg-black flex items-center justify-center">
      <div
        className="w-2 h-2 rounded-full animate-pulse"
        style={{ background: "rgba(160,160,255,0.4)" }}
      />
    </div>
  )

  // No está logueado — mostrar pantalla de login
  if (!isLoggedIn) return <LoginScreen />

  return (
    <>
      {showSplash && (
        <SplashScreen onComplete={() => {
          sessionStorage.setItem(SESSION_KEY, "1")
          setShowSplash(false)
        }} />
      )}
      {!showSplash && showOnboarding && (
        <Onboarding onComplete={() => setShowOnboarding(false)} />
      )}
      <Router />
    </>
  )
}

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <SettingsProvider>
          <MotionPreferences>
            <MusicProvider>
             <GenreProvider>
              {/* El visor de tarjetas vive arriba de todo: cualquier carta,
                  en cualquier pantalla, se toca y se abre aquí. */}
              <CardViewerProvider>
                <Toaster />
                <AppContent />
              </CardViewerProvider>
             </GenreProvider>
            </MusicProvider>
          </MotionPreferences>
        </SettingsProvider>
      </TooltipProvider>
    </QueryClientProvider>
  )
}
