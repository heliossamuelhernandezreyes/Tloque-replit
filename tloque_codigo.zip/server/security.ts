import type { NextFunction, Request, Response } from "express"

const STATE_CHANGING = new Set(["POST", "PUT", "PATCH", "DELETE"])

function normalizedOrigin(value: string | undefined): string | null {
  if (!value) return null
  try {
    const url = new URL(value)
    if (url.protocol !== "https:" && url.protocol !== "http:") return null
    return url.origin
  } catch {
    return null
  }
}

export function configuredPublicOrigin(): string | null {
  const explicit = normalizedOrigin(process.env.APP_URL)
  if (explicit) {
    if (process.env.NODE_ENV === "production" && !explicit.startsWith("https://")) {
      throw new Error("APP_URL must use HTTPS in production")
    }
    return explicit
  }
  const replitDomain = process.env.REPLIT_DEV_DOMAIN || process.env.REPLIT_DOMAINS?.split(",")[0]?.trim()
  return replitDomain ? normalizedOrigin(`https://${replitDomain}`) : null
}

export function publicOriginForRequest(req: Request): string {
  const configured = configuredPublicOrigin()
  if (configured) return configured
  if (process.env.NODE_ENV === "production") {
    throw new Error("APP_URL must be configured in production")
  }
  const host = req.get("host")
  if (!host || !/^[a-z0-9.:[\]-]+$/i.test(host)) throw new Error("Invalid request host")
  return `${req.protocol}://${host}`
}

export function securityHeaders(req: Request, res: Response, next: NextFunction) {
  const isWorkshop = req.path === "/taller-marcos.html"
  const workshopScriptPolicy = isWorkshop
    ? "script-src 'self' 'unsafe-inline'"
    : "script-src 'self'"
  const connectPolicy = process.env.NODE_ENV === "production"
    ? "connect-src 'self'"
    : "connect-src 'self' ws: wss: https:"
  res.setHeader("Content-Security-Policy", [
    "default-src 'self'",
    "base-uri 'self'",
    "object-src 'none'",
    isWorkshop ? "frame-ancestors 'self'" : "frame-ancestors 'none'",
    "form-action 'self'",
    workshopScriptPolicy,
    "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
    "font-src 'self' data: https://fonts.gstatic.com",
    "img-src 'self' data: blob: https:",
    "media-src 'self' data: blob: https:",
    connectPolicy,
    "frame-src 'self'",
    "worker-src 'self' blob:",
  ].join("; "))
  res.setHeader("X-Content-Type-Options", "nosniff")
  res.setHeader("X-Frame-Options", isWorkshop ? "SAMEORIGIN" : "DENY")
  res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin")
  res.setHeader("Permissions-Policy", "camera=(), microphone=(), geolocation=(), payment=(self)")
  res.setHeader("Cross-Origin-Opener-Policy", "same-origin")
  res.setHeader("X-Permitted-Cross-Domain-Policies", "none")
  if (req.secure && process.env.NODE_ENV === "production") {
    res.setHeader("Strict-Transport-Security", "max-age=31536000; includeSubDomains")
  }
  if (req.path.startsWith("/api/auth") || req.path.startsWith("/api/wallet")
      || req.path.startsWith("/api/audiobook") || req.path.startsWith("/api/audiobooks")
      || req.path.startsWith("/api/tokens") || req.path.startsWith("/api/account")) {
    res.setHeader("Cache-Control", "no-store")
  }
  next()
}

export function sameOriginProtection(req: Request, res: Response, next: NextFunction) {
  if (!STATE_CHANGING.has(req.method) || req.path === "/api/payments/webhook") return next()
  const fetchSite = req.get("sec-fetch-site")
  if (fetchSite === "cross-site") {
    return res.status(403).json({ message: "Origen no permitido" })
  }
  const originHeader = normalizedOrigin(req.get("origin"))
  if (!originHeader) {
    // Los navegadores modernos envían Origin o Sec-Fetch-Site en mutaciones.
    // En producción, una petición autenticada sin ninguno de los dos es
    // indistinguible de un POST de formulario CSRF legado.
    if (process.env.NODE_ENV === "production" && req.isAuthenticated()
        && fetchSite !== "same-origin") {
      return res.status(403).json({ message: "Origen no permitido" })
    }
    return next()
  }

  const configured = configuredPublicOrigin()
  if (configured && originHeader === configured) return next()
  if (process.env.NODE_ENV !== "production") {
    const requestOrigin = normalizedOrigin(`${req.protocol}://${req.get("host") || ""}`)
    if (originHeader === requestOrigin) return next()
  }
  return res.status(403).json({ message: "Origen no permitido" })
}
