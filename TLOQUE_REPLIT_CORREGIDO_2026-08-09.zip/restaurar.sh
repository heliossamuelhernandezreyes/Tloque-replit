#!/usr/bin/env bash
set -euo pipefail

backup_file="${1:-}"
destination="${2:-$PWD}"
confirmation="${3:-}"

if [[ ! -f "$backup_file" ]]; then
  echo "No se encontró el respaldo indicado." >&2
  exit 2
fi
destination="$(cd "$destination" && pwd -P)"
if [[ "$destination" == "/" || "$destination" == "/home" || "$destination" == "/home/runner" ]]; then
  echo "Destino demasiado amplio: $destination" >&2
  exit 2
fi
if [[ "$confirmation" != "RESTAURAR" ]]; then
  echo "Operación detenida. Para restaurar usa como tercer argumento: RESTAURAR" >&2
  exit 2
fi

tar -xzf "$backup_file" -C "$destination"
cd "$destination"
npm ci
npm run check
npm run build
echo "Respaldo restaurado. La base de datos no fue modificada."
