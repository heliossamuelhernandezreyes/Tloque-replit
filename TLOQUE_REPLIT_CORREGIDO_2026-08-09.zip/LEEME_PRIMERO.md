# Tloque — corrección segura para Replit

Esta entrega corrige la pantalla negra y refuerza el arranque, autenticación,
pagos, conexión con PostgreSQL, caché, accesibilidad y comprobaciones de código.

No incluye una base de datos, no contiene Secrets y no ejecuta migraciones. Las
migraciones 0001–0007 que ya aplicaste permanecen intactas.

## Instalación desde Shell

1. Sube `TLOQUE_REPLIT_CORREGIDO_2026-08-09.zip` a la raíz del Repl.
2. Detén el proceso actual con **Stop**.
3. Copia y pega este bloque completo en Shell:

```bash
release_tmp="$(mktemp -d /tmp/tloque_corregido.XXXXXX)" && \
unzip -q "/home/runner/workspace/TLOQUE_REPLIT_CORREGIDO_2026-08-09.zip" -d "$release_tmp" && \
bash "$release_tmp/instalar.sh" "/home/runner/workspace"
```

4. Espera el mensaje `Tloque quedó instalado y verificado`.
5. Pulsa **Run**. El workflow debe seguir siendo `npm run dev`, puerto 5000 y
   salida webview.

El instalador crea un respaldo antes de reemplazar archivos y muestra su ruta.
No elimina ni sustituye `.replit`, Secrets, Git ni PostgreSQL.

## Secrets que debes comprobar

Antes de publicar, configura como mínimo:

- `APP_URL`: dominio público HTTPS exacto.
- `ADMIN_EMAIL`: tu correo real de Google.
- `SESSION_SECRET`: cadena aleatoria de al menos 32 caracteres.
- `GOOGLE_CLIENT_ID` y `GOOGLE_CLIENT_SECRET`.

Para Stripe deben existir juntos `STRIPE_SECRET_KEY` y
`STRIPE_WEBHOOK_SECRET`. La Tinta beta gratuita queda apagada salvo que tú
configures deliberadamente `PAYMENTS_BETA_MODE=true`.

## Si el ZIP aparece con otro nombre

Localízalo sin adivinar:

```bash
find "/home/runner/workspace" -maxdepth 2 -type f -iname "*.zip"
```

Sustituye solamente la ruta del ZIP en el bloque de instalación.

## Qué esperar al iniciar

Ya no debe aparecer una pantalla completamente negra. Primero se muestra
`Iniciando Tloque`; después aparece el acceso o la aplicación. Si la sesión o
React fallan, se muestra una explicación y un botón para reintentar o recargar.

El informe completo está dentro de
`payload/docs/AUDITORIA_CORRECCION_2026-08-09.md`.
