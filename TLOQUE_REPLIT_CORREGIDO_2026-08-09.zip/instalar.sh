#!/usr/bin/env bash
set -euo pipefail

release_root="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
destination="${1:-$PWD}"
destination="$(cd "$destination" && pwd -P)"

if [[ "$destination" == "/" || "$destination" == "/home" || "$destination" == "/home/runner" ]]; then
  echo "Destino demasiado amplio: $destination" >&2
  exit 2
fi
if [[ ! -f "$release_root/payload/package.json" || ! -f "$release_root/MANIFEST.sha256" ]]; then
  echo "El paquete está incompleto; no se instaló nada." >&2
  exit 2
fi

echo "Verificando integridad del paquete..."
(cd "$release_root" && sha256sum -c MANIFEST.sha256)

if [[ -n "$(find "$destination" -mindepth 1 -maxdepth 1 -print -quit)" \
      && ! -f "$destination/package.json" ]]; then
  echo "El destino contiene archivos, pero no parece el proyecto Tloque: $destination" >&2
  exit 2
fi

timestamp="$(date -u +%Y%m%dT%H%M%SZ)"
backup_dir="$destination/.tloque_backups"
backup_file="$backup_dir/codigo_antes_de_${timestamp}.tar.gz"
mkdir -p "$backup_dir"

echo "Creando respaldo recuperable..."
tar \
  --exclude='./node_modules' \
  --exclude='./dist' \
  --exclude='./.git' \
  --exclude='./.tloque_backups' \
  -czf "$backup_file" -C "$destination" .

echo "Instalando código corregido sin tocar .replit, Secrets ni la base de datos..."
cp -a "$release_root/payload/." "$destination/"

cd "$destination"
echo "Instalando dependencias verificadas..."
npm ci

echo "Comprobando TypeScript..."
npm run check

echo "Ejecutando pruebas..."
npm test

echo "Generando build de producción..."
npm run build

echo
echo "Tloque quedó instalado y verificado."
echo "Base de datos: sin cambios; no hay SQL nuevo que ejecutar."
echo "Respaldo: $backup_file"
echo "Siguiente paso: vuelve a Replit y pulsa Stop/Run."
